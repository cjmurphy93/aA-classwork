# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...


npm install --save webpack
npm install --save webpack-cli
npm install --save react
npm install --save react-dom
npm install --save react-router-dom
npm install --save redux
npm install --save react-redux
npm install --save @babel/core
npm install --save @babel/preset-react
npm install --save @babel/preset-env
npm install --save babel-loader

 $.ajax({
        method: 'POST',
        url: "/api/users",
        data: {
        user: {username: "hello",
        password: "1234567" }
        }
    })