class Card
    attr_reader :number, :value
    def initialize(num,value)
        @number = num
        @value = value
    end
end