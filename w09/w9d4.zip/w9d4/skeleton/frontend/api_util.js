const APIUtil = {
    followUser: id => (
        $.ajax({
            url: `/users/${id}/follow`,
            dataType: 'json',
            method: 'POST'
        }) 
    ),
    // bro lmao
    // I think I found out what it is... Look at the solutions brackets and we have the curly ones after the fat arrow.
    //What??
    unfollowUser: id => (
        $.ajax({
            url: `/users/${id}/follow`,
            dataType: 'json',
            method: 'DELETE'
        })
    ) //Really?
    // is it because we are already inside an object?   ama ask peter real quick 
} // possibly, It could be a different thing due to the promise? <= doubt it tho
 // lol lmk how it works ????NO!!lol
 // we going to have to get answers lol
 // dont close the live session yet ama show my circle leader to see if we can get some answers sounds good!
 // dont clo/se/ theif  syou figure it out let me know lol
// const APIUtil = {

//     followUser: id => APIUtil.changeFollowStatus(id, 'POST'),

//     unfollowUser: id => APIUtil.changeFollowStatus(id, 'DELETE'),

//     changeFollowStatus: (id, method) => ( <- they have it around a parenthesis and we have it around curlys
//         $.ajax({
//             url: `/users/${id}/follow`,
//             dataType: 'json',
//             method
//         })
//     )
// }
module.exports = APIUtil;